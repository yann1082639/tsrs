VERSION = (1, 4, 1)

__version__ = '.'.join(map(str, VERSION))
